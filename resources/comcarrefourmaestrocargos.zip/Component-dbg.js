sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("com.carrefour.maestrocargos.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);