sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("com.carrefour.formularioasientos.controller.App", {
      onInit() {
      }
  });
});