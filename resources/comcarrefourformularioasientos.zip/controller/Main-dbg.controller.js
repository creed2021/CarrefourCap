sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "com/carrefour/formularioasientos/thirdparty/xlsx"
], (Controller, MessageToast, MessageBox, XLSX) => {
    "use strict";

    return Controller.extend("com.carrefour.formularioasientos.controller.Main", {
       onInit: function () {

            //precarga datos
            this.getView().byId("txtsociedad").setValue("INCA");
            this.getView().byId("txtClaseDocumento").setValue("SA");
            this.getView().byId("txtreferencia").setValue("provisiones con reversa");
            //Obtener usuario activo

            //var userInfo = sap.ushell.Container.getService("UserInfo");
            //this.getView().byId("txtsolicitante").setValue(userInfo.getFullName());


            // Obtener usuario activo si estás en FLP
            if (sap.ushell && sap.ushell.Container) {
                var userInfo = sap.ushell.Container.getService("UserInfo");
                this.getView().byId("txtsolicitante").setValue(userInfo.getFullName());
            } else {
                // Modo local: mock
                this.getView().byId("txtsolicitante").setValue("Usuario Local");
            }

            var oAsientosModel = new sap.ui.model.json.JSONModel([]);
            this.getView().setModel(oAsientosModel, "Asientos");
        }
        ,

        onControl: function () {
            var oView = this.getView();
            var oInputSolicitante = oView.byId("txtsolicitante");
            var oInputSector = oView.byId("txtsector");
            var onInputSociedad = oView.byId("txtsociedad");
            var onInputMoneda = oView.byId("txtMoneda");
            var onCBTipoAsiento = oView.byId("cbTipoAsiento");
            var onCBMotivo = oView.byId("cbMotivo");
            var onInputReferencia = oView.byId("txtreferencia");
            var onInputCabecera = oView.byId("txttextocabecera");
            var onInputClaseDoc = oView.byId("txtClaseDocumento");
            var onInputPeriodo = oView.byId("txtPeriodo");

            // validar Solicitante
            if (!oInputSolicitante.getValue()) {
                oInputSolicitante.setValueState("Error");
                oInputSolicitante.setValueStateText("Este campo es obligatorio");
            } else {
                oInputSolicitante.setValueState("None");
            }

            // validar Sector
            if (!oInputSector.getValue()) {
                oInputSector.setValueState("Error");
                oInputSector.setValueStateText("Debe ingresar el Sector");
            } else {
                oInputSector.setValueState("None");
            }

            // validar Sociedad
            if (!onInputSociedad.getValue()) {
                onInputSociedad.setValueState("Error");
                onInputSociedad.setValueStateText("Debe ingresar la Sociedad");
            } else {
                onInputSociedad.setValueState("None");
            }

            // validar Moneda
            if (!onInputMoneda.getValue()) {
                onInputMoneda.setValueState("Error");
                onInputMoneda.setValueStateText("Debe ingresar la Moneda");
            } else {
                onInputMoneda.setValueState("None");
            }

            // validar TipoAsiento
            if (!onCBTipoAsiento.getValue()) {
                onCBTipoAsiento.setValueState("Error");
                onCBTipoAsiento.setValueStateText("Debe seleccionar Tipo Asiento");
            } else {
                onCBTipoAsiento.setValueState("None");
            }

            // validar Motivo
            if (!onCBMotivo.getValue()) {
                onCBMotivo.setValueState("Error");
                onCBMotivo.setValueStateText("Debe seleccionar el Motivo");
            } else {
                onCBMotivo.setValueState("None");
            }

            // validar Cabecera
            if (!onInputCabecera.getValue()) {
                onInputCabecera.setValueState("Error");
                onInputCabecera.setValueStateText("Debe Ingresar un texto cabecera");
            } else {
                onInputCabecera.setValueState("None");
            }

            // validar Referencia
            if (!onInputReferencia.getValue()) {
                onInputReferencia.setValueState("Error");
                onInputReferencia.setValueStateText("Debe Ingresar una referencia");
            } else {
                onInputReferencia.setValueState("None");
            }

            // validar Clase Documento
            if (!onInputClaseDoc.getValue()) {
                onInputClaseDoc.setValueState("Error");
                onInputClaseDoc.setValueStateText("Debe Ingresar una Clase del Documento");
            } else {
                onInputClaseDoc.setValueState("None");
            }

            // validar Periodo
            if (!onInputPeriodo.getValue()) {
                onInputPeriodo.setValueState("Error");
                onInputPeriodo.setValueStateText("Debe Ingresar un Periodo");
            } else {
                onInputPeriodo.setValueState("None");
            }

            // 1. Leer periodo ingresado (ej: "09/2025" o "092025")
            var sPeriodo = oView.byId("txtPeriodo").getValue(); // tu input periodo
            var mes, anio;
            if (sPeriodo.includes("/")) {
                [mes, anio] = sPeriodo.split("/");
            } else {
                mes = sPeriodo.substring(0, 2);
                anio = sPeriodo.substring(2);
            }
            mes = parseInt(mes, 10);
            anio = parseInt(anio, 10);

            // rango válido
            var fechaInicio = new Date(anio, mes - 1, 1);  // primer día del mes
            var fechaFin = new Date(anio, mes, 0);         // último día del mes

            // 2. Leer las fechas de los DatePicker
            var oDatePickerCont = oView.byId("dpFechaConta");
            var oDatePickerDoc = oView.byId("dpFechaDoc");

            var dFechaCont = oDatePickerCont.getDateValue();
            var dFechaDoc = oDatePickerDoc.getDateValue();

            // 3. Validar fechas dentro del periodo
            if (dFechaCont < fechaInicio || dFechaCont > fechaFin) {
                oDatePickerCont.setValueState("Error");
                oDatePickerCont.setValueStateText("Fecha fuera del período ingresado");
            } else {
                oDatePickerCont.setValueState("None");
            }

            if (dFechaDoc < fechaInicio || dFechaDoc > fechaFin) {
                oDatePickerDoc.setValueState("Error");
                oDatePickerDoc.setValueStateText("Fecha fuera del período ingresado");
            } else {
                oDatePickerDoc.setValueState("None");
            }

        },
        onTipoAsiento: function () {
            var cbtipo = this.getView().byId("cbTipoAsiento").getValue();
            var sKey = this.getView().byId("cbTipoAsiento").getSelectedKey();
            //MessageToast.show(cbtipo);
            if (sKey == 1) {
                this.getView().byId("txtreferencia").setValue("Prov c/Reversa");
            }
            else {
                if (sKey == 2) {
                    this.getView().byId("txtreferencia").setValue("Aj Cierre");
                }
                else {
                    this.getView().byId("txtreferencia").setValue("Aj Excep");
                }
            }
        },
        onCap: async function () {

            MessageToast.show("prueba cap");
            this.onControl();
            this.ArmadoJson();

            //const token = await this.getAccessToken();
            // 3️⃣ Llamar al servicio
            await this.postCabeceraAsiento(this.ArmadoJsonPOST());
            MessageBox.show("Despues");

            // Verificar si algún campo está en error
            const oView = this.getView();
            const aCampos = [
                "txtsolicitante", "txtsector", "txtsociedad", "txtMoneda",
                "cbTipoAsiento", "cbMotivo", "txttextocabecera",
                "txtreferencia", "txtClaseDocumento", "txtPeriodo",
                "dpFechaConta", "dpFechaDoc"
            ];

            let cabeceraOk = aCampos.every(id => oView.byId(id).getValueState() !== "Error");

            if (!cabeceraOk) {
                sap.m.MessageBox.error("⚠️ Hay errores en la cabecera. Corrige antes de continuar.");
                return;
            }

            // 2️⃣ Validar que haya un Excel cargado

            if (!aAsientos || aAsientos.length === 0) {
                sap.m.MessageBox.error("Debe cargar un archivo Excel antes de confirmar.");
                return;
            }

            // 3️⃣ Validar totales (clave 40 vs 50)
            let total40 = 0, total50 = 0;
            aAsientos.forEach(item => {
                const clave = parseInt(item.Clave);
                const importe = parseFloat(item.Importe) || 0;
                if (clave === 40) total40 += importe;
                else if (clave === 50) total50 += importe;
            });

            if (Math.abs(total40 - total50) !== 0) {
                sap.m.MessageBox.error(
                    `❌ Los totales no coinciden.\nSuma clave 40 = ${total40.toFixed(2)}\nSuma clave 50 = ${total50.toFixed(2)}`
                );
                return;
            }

            //Controlar 900 registros
            if (aAsientos.length > 900) {
                MessageBox.error(
                    `El Excel no puede tener mas de 900 registros.`
                );
                return; // aborta la función entera
            }

            //4 Validar Campo Clave sea (clave 40 - 50)
            aAsientos.forEach(item => {
                const clave = parseInt(item.Clave);
                if (clave !== 40 && clave !== 50 && clave !== "40" && clave !== "50") {
                    MessageBox.error("El Excel tiene Clave Distinto a 40 y 50");
                    return;
                }
            });

            sap.m.MessageToast.show("Validaciones Correctas. llamada a CAP");
            this.ArmadoJson()
            console.log(aAsientos);
            MessageBox.show("llega hasta aca");

        },
        ArmadoJson: async function () {
            var aAsientos = this.getView().getModel("Asientos").getProperty("/");
            // 4️⃣ Obtener los valores de los campos de cabecera

            var valorPeriodo = this.getView().byId("txtPeriodo").getValue();
            var periodoMes = "";
            var periodoAnio = "";

            if (valorPeriodo && valorPeriodo.includes("/")) {
                const [mes, anio] = valorPeriodo.split("/"); // divide por "/"

                periodoMes = parseInt(mes, 10);
                periodoAnio = parseInt(anio, 10);
            }

            var oView = this.getView();
            var oCabecera = {
                claseDocumento: oView.byId("txtClaseDocumento").getValue(),
                fechaContabilizacion: oView.byId("dpFechaConta").getValue(),
                fechaDocumento: oView.byId("dpFechaDoc").getValue(),
                moneda: oView.byId("txtMoneda").getValue(),
                numeroSolicitud: "AS-2025001",
                periodoAnio: periodoAnio,
                periodoMes: periodoMes,
                referencia: oView.byId("txtreferencia").getValue(),
                sectorSolicitante: oView.byId("txtsector").getValue(),
                solicitante: oView.byId("txtsolicitante").getValue(),
                subtipoAsiento: oView.byId("cbMotivo").getValue(),
                textoCabecera: oView.byId("txttextocabecera").getValue(),
                //periodo: oView.byId("txtPeriodo").getValue(),
                tipoAsiento: oView.byId("cbTipoAsiento").getValue()
            };

            // 5️⃣ Armar estructura final del JSON
            var oPayload = {
                Cabecera: oCabecera,
                Detalle: aAsientos
            };

            // 🔁 Transformación al formato esperado por CAP
            const payload = {
                ...oPayload.Cabecera,
                items: oPayload.Detalle.map(item => ({
                    centroCosto: item.CentroCoste,
                    clave: item.Clave,
                    cuentaContable: item.CuentaContable,
                    descripcion: item.Descripcion,
                    importe: item.Importe,
                    numeroLinea: item.NroAsiento
                }))
            };

            console.log("📦 JSON Final a enviar CAP:", payload);

            // 6️⃣ Si querés, mostrarlo formateado antes de enviar:
            sap.m.MessageBox.success("JSON generado correctamente:\n\n" + JSON.stringify(payload, null, 2));

        },
        onLimpiar: function () {
            var oTable = this.byId("tblItems");
            var oModel = oTable.getModel("Asientos");
            // dejar el array vacío
            oModel.setProperty("/", []);
            sap.m.MessageToast.show("Se limpiaron los asientos cargados");
        },
        onValueHelpSolicitante: function (oEvent) {
            // Por ahora abrimos un simple Dialog con 5 nombres
            if (!this._oVHDialog) {
                this._oVHDialog = new sap.m.SelectDialog({
                    title: "Seleccionar Solicitante",
                    items: [
                        new sap.m.StandardListItem({ title: "Juan Pérez" }),
                        new sap.m.StandardListItem({ title: "María Gómez" }),
                        new sap.m.StandardListItem({ title: "Carlos López" }),
                        new sap.m.StandardListItem({ title: "Ana Rodríguez" }),
                        new sap.m.StandardListItem({ title: "Luis Fernández" })
                    ],
                    confirm: (oEvt) => {
                        var oSelected = oEvt.getParameter("selectedItem");
                        if (oSelected) {
                            this.byId("txtsolicitante").setValue(oSelected.getTitle());
                        }
                    },
                    cancel: () => {
                        // opcional
                    }
                });
            }
            this._oVHDialog.open();
        },
        onFileChangeAdjunto: function (oEvent) {
            let that = this;
            let rutaInicial = "/apidms/browser/"; //despliegue
            const oFile = oEvent.getParameter("files")?.[0];
            if (!oFile) {
                MessageBox.error("No se seleccionó ningún archivo.");
                return;
            }

            // ➤ Construir nombre nuevo: nombre_base + fecha y hora
            const nombreBase = oFile.name.substring(0, oFile.name.lastIndexOf(".")) || oFile.name;
            const extension = oFile.name.split('.').pop();
            const now = new Date();

            const timestamp = now.getDate().toString().padStart(2, '0') +
                (now.getMonth() + 1).toString().padStart(2, '0') +
                now.getFullYear().toString() +
                now.getHours().toString().padStart(2, '0') +
                now.getMinutes().toString().padStart(2, '0') +
                now.getSeconds().toString().padStart(2, '0');

            const nombreFinal = `${nombreBase}_${timestamp}.${extension}`;

            var myHeaders = new Headers();
            const formData = new FormData();
            formData.append("cmisaction", "createDocument");
            formData.append("propertyId[0]", "cmis:name");
            formData.append("propertyValue[0]", this.formatoNombreArchivo(nombreFinal));
            formData.append("propertyId[1]", "cmis:objectTypeId");
            formData.append("propertyValue[1]", "cmis:document");
            formData.append("filename", this.formatoNombreArchivo(nombreFinal));
            formData.append("_charset", "UTF-8");
            formData.append("succinct", "true");
            formData.append("includeAllowableActions", "true");
            formData.append("media", oFile, nombreFinal); // obligatorio

            const sUrl = that._getAppModulePath() + rutaInicial + "59ec1b8c-cf7c-465c-bd5b-460bcb6ca9a4/root/pupuno";

            fetch(sUrl, {
                method: "POST",
                headers: myHeaders,
                body: formData,
                redirect: 'follow'
            })
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    console.log("Archivo subido:", data);
                    MessageToast.show("Archivo subido correctamente.");
                    //Obtener Archivo Subido el ID
                    // ✅ Obtener el ID del documento subido
                    const objectId = data?.succinctProperties?.["cmis:objectId"];
                    const fileName = data?.succinctProperties?.["cmis:contentStreamFileName"];

                    if (objectId) {
                        console.log("ID del documento subido:", objectId);

                        // Guardar en un modelo JSON para reutilizar en la vista
                        const oModel = new sap.ui.model.json.JSONModel({
                            objectId: objectId,
                            fileName: fileName
                        });
                        that.getView().setModel(oModel, "DMSFile");

                        // Mostrar al usuario
                        MessageBox.show(`Archivo "${fileName}" subido con éxito. ID: ${objectId}`);
                    } else {
                        MessageBox.warning("Archivo subido, pero no se pudo obtener el ID del documento.");
                    }
                })
                .catch(err => {
                    console.error("Error al subir archivo:", err);
                    MessageBox.error(`Error: ${err.message}`);
                });
        },
        onFileChange: function (oEvent) {
          
            var aFiles = oEvent.getParameter("files");
            if (!aFiles || aFiles.length === 0) {
                sap.m.MessageToast.show("No se seleccionó ningún archivo");
                return;
            }

            var oFile = aFiles[0];
            sap.m.MessageToast.show("Leyendo: " + oFile.name);

            var reader = new FileReader();
            reader.onload = (e) => {
                var data = new Uint8Array(e.target.result);
                var workbook = XLSX.read(data, { type: "array" });
                var firstSheet = workbook.SheetNames[0];
                var excelRows = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);

                var oTable = this.byId("tblItems");
                var oModel = oTable.getModel("Asientos");
                oModel.setProperty("/", []);
                var aData = [];

                if (excelRows.length > 900) {
                    sap.m.MessageBox.error("El Excel no puede tener más de 900 registros.");
                    return;
                }

                for (var i = 0; i < excelRows.length; i++) {
                    var row = excelRows[i];
                    var cleaned = {};
                    Object.keys(row).forEach((key) => {
                        cleaned[key.trim()] = row[key];
                    });

                    var clave = cleaned["Clave"];

                    if (clave !== 40 && clave !== 50 && clave !== "40" && clave !== "50") {
                        sap.m.MessageBox.error(
                            `Error en fila ${i + 1}: Clave inválida (${clave}). Se canceló la carga.`
                        );
                        return;
                    }

                    aData.push({
                        NroAsiento: i + 1,
                        Clave: cleaned["Clave"],
                        CuentaContable: cleaned["Cuenta"],
                        Descripcion: cleaned["Descripcion Asiento"],
                        Importe:
                            cleaned["Importe"] !== undefined
                                ? parseFloat(cleaned["Importe"])
                                : 0,
                        CentroCoste: cleaned["CECO"],
                    });
                }

                oModel.setProperty("/", aData);
                sap.m.MessageToast.show("Se cargaron " + aData.length + " filas del Excel");

                // 🔽 Agregamos la validación de totales aquí 🔽
                this._validarTotales(aData);
            };
            reader.readAsArrayBuffer(oFile);
        },

        // --- nueva función de validación ---
        _validarTotales: function (aData) {
            let total40 = 0;
            let total50 = 0;

            aData.forEach((item) => {
                const clave = parseInt(item.Clave);
                const importe = parseFloat(item.Importe) || 0;

                if (clave === 40) {
                    total40 += importe;
                } else if (clave === 50) {
                    total50 += importe;
                }
            });

            if (Math.abs(total40 - total50) == 0) {
                sap.m.MessageBox.success("El saldo del Asiento es cero.")
            }
            else {
                sap.m.MessageBox.error(
                    `❌ Los totales no coinciden.\nSuma clave 40 = ${total40.toFixed(
                        2
                    )}\nSuma clave 50 = ${total50.toFixed(2)}`
                );
            }
        },
        _getAppModulePath: function () {
            const appId = this.getOwnerComponent().getManifestEntry("/sap.app/id");
            const appPath = appId.replaceAll(".", "/");
            MessageBox.show(appPath);
            return jQuery.sap.getModulePath(appPath);
        },
        //Eliminacion y formato de caracteres raros en el nombre del archivo
        formatoNombreArchivo: function (sFile) {
            var textoCodificado = encodeURIComponent(sFile);
            var sNombre = decodeURIComponent(textoCodificado);
            var reemplazos = {
                'Ã': 'A', 'À': 'A', 'Á': 'A', 'Ä': 'A', 'Â': 'A',
                'È': 'E', 'É': 'E', 'Ë': 'E', 'Ê': 'E',
                'Ì': 'I', 'Í': 'I', 'Ï': 'I', 'Î': 'I',
                'Ò': 'O', 'Ó': 'O', 'Ö': 'O', 'Ô': 'O',
                'Ù': 'U', 'Ú': 'U', 'Ü': 'U', 'Û': 'U',
                'ã': 'a', 'à': 'a', 'á': 'a', 'ä': 'a', 'â': 'a',
                'è': 'e', 'é': 'e', 'ë': 'e', 'ê': 'e',
                'ì': 'i', 'í': 'i', 'ï': 'i', 'î': 'i',
                'ò': 'o', 'ó': 'o', 'ö': 'o', 'ô': 'o',
                'ù': 'u', 'ú': 'u', 'ü': 'u', 'û': 'u',
                'Ñ': 'N', 'ñ': 'n',
                'Ç': 'c', 'ç': 'c'
            };
            var textoNormalizado = sNombre.replace(/[ÃÀÁÄÂÈÉËÊÌÍÏÎÒÓÖÔÙÚÜÛãàáäâèéëêìíïîòóöôùúüûÑñÇç]/g, function (match) {
                return reemplazos[match];
            });
            return textoNormalizado;
        },
        //Obtener el ID del repostiorio
        onObtenerRepositorioId: function () {
            //return "0687b0df-65d8-45b5-802c-a5e76db45277";//PRD
            return "59ec1b8c-cf7c-465c-bd5b-460bcb6ca9a4";//DEV
        },
        ControlAdjuntoDms: function (nombreArchivo) {

            let that = this;
            let rutaInicial = "/apidms/browser/"; //despliegue

            const sUrlList = that._getAppModulePath() + rutaInicial + "59ec1b8c-cf7c-465c-bd5b-460bcb6ca9a4/root/pupuno?succinct=true";

            return fetch(sUrlList)
                .then(res => res.json())
                .then(data => {
                    const files = data.objects || [];
                    const yaExiste = files.some(f =>
                        f.object.succinctProperties["cmis:name"] === nombreArchivo
                    );
                    return yaExiste; // devuelve true o false
                })
                .catch(err => {
                    console.error("Error al consultar DMS:", err);
                    return false; // En error, asumimos que no existe (o manejar de otra forma)
                });
        },
        postCabeceraAsiento: async function (payload) {
            const oModel = this.getView().getModel(); // OData V4 model

            try {
                // Vincular a la entidad CabeceraAsiento
                const oListBinding = oModel.bindList("/CabeceraAsiento");
                const oContext = oListBinding.create(payload);

               
                //oModel.submit(id de grupo actual);

                //oContext.created().then()
                //getproperty

                const data = await oContext.requestObject(); // obtener datos creados
                sap.m.MessageBox.success(`✅ Registro creado correctamente\nID: ${data.ID}`);
                console.log("Respuesta CAP:", data);

            } catch (error) {
                console.error("Error CAP:", error);
                sap.m.MessageBox.error("❌ Error al crear el registro.\n" + error.message);
            }
        },

        ArmadoJsonPOST: async function () {
            var aAsientos = this.getView().getModel("Asientos").getProperty("/");
            // 4️⃣ Obtener los valores de los campos de cabecera
            var valorPeriodo = this.getView().byId("txtPeriodo").getValue();
            var periodoMes = "";
            var periodoAnio = "";

            if (valorPeriodo && valorPeriodo.includes("/")) {
                const [mes, anio] = valorPeriodo.split("/"); // divide por "/"

                periodoMes = parseInt(mes, 10);
                periodoAnio = parseInt(anio, 10);
            }

            var oView = this.getView();
            var oCabecera = {
                claseDocumento: oView.byId("txtClaseDocumento").getValue(),
                fechaContabilizacion: oView.byId("dpFechaConta").getValue(),
                fechaDocumento: oView.byId("dpFechaDoc").getValue(),
                moneda: oView.byId("txtMoneda").getValue(),
                numeroSolicitud: "AS-2025001",
                periodoAnio: periodoAnio,
                periodoMes: periodoMes,
                referencia: oView.byId("txtreferencia").getValue(),
                sectorSolicitante: oView.byId("txtsector").getValue(),
                solicitante: oView.byId("txtsolicitante").getValue(),
                subtipoAsiento: oView.byId("cbMotivo").getValue(),
                textoCabecera: oView.byId("txttextocabecera").getValue(),
                //periodo: oView.byId("txtPeriodo").getValue(),
                tipoAsiento: oView.byId("cbTipoAsiento").getValue()
            };

            // 5️⃣ Armar estructura final del JSON
            var oPayload = {
                Cabecera: oCabecera,
                Detalle: aAsientos
            };

            // 🔁 Transformación al formato esperado por CAP
            const payload = {
                ...oPayload.Cabecera,
                items: oPayload.Detalle.map(item => ({
                    centroCosto: item.CentroCoste,
                    clave: item.Clave,
                    cuentaContable: item.CuentaContable,
                    descripcion: item.Descripcion,
                    importe: item.Importe,
                    numeroLinea: item.NroAsiento
                }))
            };

            return payload;

        }

    });
});