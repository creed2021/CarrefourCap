sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/carrefour/formularioasientos/model/models"
], (UIComponent, models) => {
    "use strict";

    return UIComponent.extend("com.carrefour.formularioasientos.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },

        init() {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);
                        sap.ui.loader.config({
                paths: {
                    "xlsx": sap.ui.require.toUrl("com/carrefour/formularioasientos/thirdparty/xlsx")
                }
            });

            // set the device model
            this.setModel(models.createDeviceModel(), "device");

            // enable routing
            this.getRouter().initialize();
        }
    });
});