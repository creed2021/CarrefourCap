sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("ns.asientosajustesweb.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);